# Quartz 


Quartz skin for KODI 21 (Omega)

Follow the link below for the latest news and information about this classic skin for KODI.

https://forum.kodi.tv/showthread.php?tid=377697

Note: See branches for older versions of quartz.
